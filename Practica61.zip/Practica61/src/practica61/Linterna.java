/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica61;

/**
 * Linterna de los telefono
 * 
 * @author Paco, Nicolas
 * @version 1.0
 * 
 * Para la clase madre: 
 * @see Telefono
 */
public class Linterna {

    private boolean encendido;
    /**
     * Metodo para encender la linterna
     * 
     */
    public void encender() {
        System.out.println("Mucha luz!");
        this.setEncendido(true);
    }
    /**
     * Metodo para apagar la linterna
     * 
     */
    public void apagar(){
        System.out.println("Se va la luz");
        this.setEncendido(false);
    }
    /**
     * Metodo que revisa si esta encendida la linterna
     * 
     * @return encendido - Devuelve un booleano que depende de si la linterna esta encendida o no.
     */
    public boolean isEncendido() {
        return encendido;
    }

    public void setEncendido(boolean encendido) {
        this.encendido = encendido;
    }

    
}

