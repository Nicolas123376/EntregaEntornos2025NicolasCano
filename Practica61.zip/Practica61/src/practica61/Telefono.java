/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica61;

/**
 * Clase madre Telefono de la cual se definen parametros y metodos cumnes entre Pijiphone y Android
 * 
 * @author Paco, Nicolas
 * @version 1.0
 */
public abstract class Telefono {
    /**
     * Atributos generales sobre la informacion del telefono, incluyendo PUk, precio, color, marca.
     * bateria es para contar la bateria de cada telefono y esta se carga dependiendo del mismo.
     * llamadas y llamadasTotales contabilizan las llamadas individuales y totales de todos los telefonos respectivamente.
     * Linterna es la linterna que tienen todos los telefonos
     */
    private final String PUK;
    private double precio;
    private String color;
    private int bateria;
    private String marca;
    private int llamadas;
    private static int llamadasTotales;
    private Linterna linternita;
    /**
     * Constructor del tel�fono
     * @param colorIn Par�metro asociado al color
     * @param precioIn Parametro asociado al precio
     * @param marcaIn Parametro asociado a la marca
     */
    public Telefono(String colorIn, double precioIn, String marcaIn) {
        this.color = colorIn;
        this.PUK = "" + (int) Math.floor(Math.random() * 100000000);
        this.precio = precioIn;
        this.marca = marcaIn;
        this.llamadas = 0;
        
    }
    /**
     * Metodo llamar de la clase telefono el cual varia dependiendo de la marca del telefono 
     * 
     */
    public void llamar() {
        System.out.println("Piiii, piiiii...");
        this.esperar(4);
        System.out.println("---**CONVERSACI�N PRIVADA**---");
        this.esperar(5);
        System.out.println("pi pi pi, pi pi pi, ...");
        this.setLlamadas(this.getLlamadas() + 1);
        Telefono.setLlamadasTotales(Telefono.getLlamadasTotales() + 1); //
        // this.llamadas = this.llamadas + 1;
    }

    /**
     * Este m�todo sirve para esperar
     * 
     * @param segundos num segundos de espera
     * @throws Exception e - Variable con la excepcion general
     */
    public void esperar(int segundos) {
        try {
            Thread.sleep(segundos * 1000);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    /**
     * Este m�todo sirve para cargar los telefonos
     * 
     */
    public abstract void cargar();
    
    /**
     * Este m�todo sirve obtener la linterna
     * 
     * @return - devuelve la linterna
     */
    public Linterna getLinternita() {
        return linternita;
    }
    
    /**
     * Este m�todo sirve para poner la linterna
     * 
     * @param linternita Es el nombre de variable dado a la linterna
     */
    public void setLinternita(Linterna linternita) {
        this.linternita = linternita;
    }
    
   
    /**
     * Este m�todo sirve para obtener el numero de llamadas totales
     * 
     * @return - devuleve el numero de llamadas totales
     */
    public static int getLlamadasTotales() {
        return llamadasTotales;
    }
    /**
     * Este m�todo sirve para poner un numero de llamadas totales
     * 
     * @param llamadasTotales Numero de llamadas totales.
     */
    public static void setLlamadasTotales(int llamadasTotales) {
        Telefono.llamadasTotales = llamadasTotales;
    }

    
    /**
     * Este m�todo sirve para obtener el numero de llamadas
     * 
     * @return - devuleve el numero llamadas
     */ 
    public int getLlamadas() {
        return llamadas;
    }
/**
     * Este m�todo sirve para poner un numero de llamadas totales
     * 
     * @param llamadas Numero de llamadas.
     */
    public void setLlamadas(int llamadas) {
        this.llamadas = llamadas;
    }
    /**
     * Este m�todo sirve para obtener la marca
     * 
     * @return - devuleve la marca
     */
    public String getMarca() {
        return marca;
    }
/**
     * Este m�todo sirve para poner la marca.
     * 
     * @param marca Marca del telefono.
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }
    /**
     * Este m�todo sirve para obtener el PUK
     * 
     * @return - devuleve el PUK
     */
    public String getPuk() {
        return PUK;
    }
    /**
     * Este m�todo sirve para obtener el precio
     * 
     * @return - devuleve el precio
     */
    public double getPrecio() {
        return precio;
    }
/**
     * Este m�todo sirve para poner el precio.
     * 
     * @param precio Precio del telefono.
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    /**
     * Este m�todo sirve para obtener el color
     * 
     * @return - devuleve el color
     */
    public String getColor() {
        return color;
    }
/**
     * Este m�todo sirve para poner el color.
     * 
     * @param color Color del telefono.
     */
    public void setColor(String color) {
        this.color = color;
    }
    /**
     * Este m�todo sirve para obtener la bateria
     * 
     * @return - devuleve la bateria
     */
    public int getBateria() {
        return bateria;
    }
/**
     * Este m�todo sirve para poner la bateria
     * 
     * @param bateria Bateria del telefono.
     */
    public void setBateria(int bateria) {
        this.bateria = bateria;
    }

}
