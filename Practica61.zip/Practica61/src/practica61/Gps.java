/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica61;

/**
 * GPS de Pijiphone
 * 
 * @author Paco, Nicolas
 * @version 1.0
 * 
 * Para la clase madre: 
 * @see Pijiphone
 */
public class Gps {
    private String UbicacionActual;
    /**
     * Metodo para actualizar la ubicacion del gps
     * 
     * @return UbicacionActual - Devuleve la ubicacion actualizada
     */
    public String ActualizarUbicacion() {
        UbicacionActual = "Estas ahora aqui";
        return UbicacionActual;
    }
}
