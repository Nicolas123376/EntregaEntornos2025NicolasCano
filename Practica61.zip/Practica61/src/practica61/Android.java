/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica61;

/**
 * Especificaciones para el tipo de telefono Android
 * 
 * @author Paco, Nicolas
 * @version 1.0
 * 
 * Para la clase madre: 
 * @see Telefono
 */
public class Android extends Telefono {
    /**
     * Constructor del tel�fono Pijiphone
     * @param colorIn Par�metro asociado al color
     */
    public Android(String colorIn) {
        super(colorIn, 200, "%-roid");
    }
    /**
     * Metodo cpintar exclusivo de Android, el cual abre paint.
     * 
     */
    public void pintar() {
        try {
            ProcessBuilder process = new ProcessBuilder("mspaint.exe");
            process.start();
        } catch (Exception e) {
            System.out.println("No encuentro el paint");
        }
    }
    /**
     * Metodo cargar especifico de Android
     * 
     */
    @Override
    public void cargar() {
        setBateria(getBateria() + (getBateria() / 3) + 20);
        if (getBateria() > 100) {
            setBateria(100);
        }
    }
}
