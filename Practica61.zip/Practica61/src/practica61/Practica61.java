/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package practica61;

/**
 * Main donde se realizaron las pruebas 
 * 
 * @author Paco, Nicolas.
 * @version 1.0
 * @see https://view.genially.com/625efe3c84255d001146c045
 */
public class Practica61 {
    public static void main(String[] args) {
    // definici�n de variables
    Linterna linterna = new Linterna();
    Gps gps1 = new Gps();
    Pijiphone pijiphone1 = new Pijiphone("verde");
    pijiphone1.llamar();
    System.out.println(pijiphone1.getMarca().toUpperCase());
    gps1.ActualizarUbicacion();
}
}
