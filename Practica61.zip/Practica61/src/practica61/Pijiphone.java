/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica61;

/**
 * Especificaciones para el tipo de telefono Pijiphone
 * 
 * @author Paco, Nicolas
 * @version 1.0
 * 
 * Para la clase madre: 
 * @see Telefono
 */
public class Pijiphone extends Telefono {
    /**
     * Gps exclusivo de Pijiphone
     */
    private Gps gpsConcreto;

    /**
     * Constructor del tel�fono Pijiphone
     * @param colorIn Par�metro asociado al color
     */
    public Pijiphone(String colorIn) {
        super(colorIn, 700, "Pijiphone");
        this.gpsConcreto = new Gps();
    }
    /**
     * Metodo llamar especifico de Pijiphone
     * 
     */
    @Override
    public void llamar() {
        super.llamar(); //
        System.out.println("Esta llamada va a ser grabada");
    }
    /**
     * Metodo cargar especifico de Pijiphone
     * 
     */
    @Override
    public void cargar() {
        setBateria(getBateria() + 70);
        if (getBateria() > 100) {
            setBateria(100);
        }
    }
}

